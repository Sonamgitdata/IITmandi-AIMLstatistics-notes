"""
Simple Linear Regression on House Price Data
=============================================
We predict House Price (y) using only ONE feature: Area_sqft (x).

MATHEMATICAL FOUNDATION
-----------------------
The model equation is:
    y = b0 + b1 * x

    where:
        y    = predicted house price
        x    = area in square feet
        b0   = intercept (price when area is 0, a baseline constant)
        b1   = slope (how much price changes per 1 sqft increase)

We find b0 and b1 by minimizing the Sum of Squared Errors (SSE):
    SSE = sum( (y_actual - y_predicted)^2 )

The closed-form solution using Ordinary Least Squares (OLS):
    b1 = sum( (xi - x_mean) * (yi - y_mean) ) / sum( (xi - x_mean)^2 )
       = Cov(x, y) / Var(x)

    b0 = y_mean - b1 * x_mean
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score


# -----------------------------------------------------------------------
# STEP 1 - LOAD DATA
# -----------------------------------------------------------------------
# Read the Excel file that contains 800 house records
df = pd.read_excel("house_prices.xlsx")

print("Dataset shape:", df.shape)
print("\nFirst 5 rows:")
print(df.head())

print("\nBasic statistics:")
print(df[["Area_sqft", "Price_USD"]].describe())


# -----------------------------------------------------------------------
# STEP 2 - SELECT FEATURE AND TARGET
# -----------------------------------------------------------------------
# x = input feature (1D for simple linear regression)
# y = target variable we want to predict
x = df[["Area_sqft"]].values   # shape: (800, 1)  -- sklearn needs 2D array
y = df["Price_USD"].values      # shape: (800,)


# -----------------------------------------------------------------------
# STEP 3 - SPLIT DATA INTO TRAIN / VALIDATION / TEST
# -----------------------------------------------------------------------
# Common split ratios: 70% train, 15% validation, 15% test
#
# WHY SPLIT?
#   - Train set    : model learns the coefficients b0 and b1 from this
#   - Validation   : tune hyperparameters without touching the test set
#   - Test set     : final unbiased evaluation of model performance
#
# We do this in two steps:
#   Step A: split off 30% as temp (will become val + test)
#   Step B: split temp 50/50 into validation and test

x_train, x_temp, y_train, y_temp = train_test_split(
    x, y, test_size=0.30, random_state=42
)

x_val, x_test, y_val, y_test = train_test_split(
    x_temp, y_temp, test_size=0.50, random_state=42
)

print("\n--- Data Split Summary ---")
print(f"  Total samples  : {len(x)}")
print(f"  Train samples  : {len(x_train)}  ({len(x_train)/len(x)*100:.1f}%)")
print(f"  Val samples    : {len(x_val)}    ({len(x_val)/len(x)*100:.1f}%)")
print(f"  Test samples   : {len(x_test)}   ({len(x_test)/len(x)*100:.1f}%)")


# -----------------------------------------------------------------------
# STEP 4 - MANUAL OLS CALCULATION (to understand the math)
# -----------------------------------------------------------------------
# We manually compute b1 and b0 using the OLS formulas shown at the top.
# This is just for understanding -- sklearn will do the same thing.

x_flat = x_train.flatten()     # convert to 1D for manual calculation
y_flat = y_train

x_mean = np.mean(x_flat)       # mean of all training x values
y_mean = np.mean(y_flat)       # mean of all training y values

# Numerator: sum of (xi - x_mean) * (yi - y_mean)
# This is the covariance (numerator part) between x and y
numerator = np.sum((x_flat - x_mean) * (y_flat - y_mean))

# Denominator: sum of (xi - x_mean)^2
# This is the variance (numerator part) of x
denominator = np.sum((x_flat - x_mean) ** 2)

b1_manual = numerator / denominator       # slope
b0_manual = y_mean - b1_manual * x_mean  # intercept

print("\n--- Manual OLS Coefficients ---")
print(f"  Slope     (b1) = {b1_manual:.4f}  (price increases by ${b1_manual:.2f} per sqft)")
print(f"  Intercept (b0) = {b0_manual:.2f}")


# -----------------------------------------------------------------------
# STEP 5 - FIT MODEL USING SKLEARN (confirms manual results)
# -----------------------------------------------------------------------
# sklearn's LinearRegression uses the same OLS internally
model = LinearRegression()
model.fit(x_train, y_train)

b1_sklearn = model.coef_[0]       # slope coefficient
b0_sklearn = model.intercept_     # intercept

print("\n--- Sklearn Coefficients (should match manual) ---")
print(f"  Slope     (b1) = {b1_sklearn:.4f}")
print(f"  Intercept (b0) = {b0_sklearn:.2f}")


# -----------------------------------------------------------------------
# STEP 6 - MAKE PREDICTIONS
# -----------------------------------------------------------------------
# For each x value, apply:  y_hat = b0 + b1 * x
#
# This is the dot product: y_hat = X @ [b1] + b0
# which sklearn handles internally

y_pred_train = model.predict(x_train)
y_pred_val   = model.predict(x_val)
y_pred_test  = model.predict(x_test)


# -----------------------------------------------------------------------
# STEP 7 - EVALUATE PERFORMANCE METRICS
# -----------------------------------------------------------------------
#
# R-squared (R2):
#   R2 = 1 - SSE / SST
#   SSE = sum( (y_actual - y_predicted)^2 )   -- residual variance
#   SST = sum( (y_actual - y_mean)^2 )         -- total variance
#   R2 = 1 means perfect fit, R2 = 0 means model predicts the mean
#
# Mean Squared Error (MSE):
#   MSE = (1/n) * sum( (y_actual - y_predicted)^2 )
#   Units: squared dollars -- hard to interpret directly
#
# Root Mean Squared Error (RMSE):
#   RMSE = sqrt(MSE)
#   Units: dollars -- easier to interpret (average prediction error)
#
# Mean Absolute Error (MAE):
#   MAE = (1/n) * sum( |y_actual - y_predicted| )
#   Units: dollars -- less sensitive to large outliers than RMSE

def evaluate(y_true, y_pred, split_name):
    r2   = r2_score(y_true, y_pred)
    mse  = mean_squared_error(y_true, y_pred)
    rmse = np.sqrt(mse)
    mae  = mean_absolute_error(y_true, y_pred)
    print(f"\n  [{split_name}]")
    print(f"    R2 Score : {r2:.4f}   (proportion of variance explained)")
    print(f"    MSE      : ${mse:,.0f}")
    print(f"    RMSE     : ${rmse:,.0f}  (average error in dollars)")
    print(f"    MAE      : ${mae:,.0f}  (average absolute error in dollars)")
    return r2, rmse, mae

print("\n--- Model Evaluation ---")
r2_tr, rmse_tr, mae_tr = evaluate(y_train, y_pred_train, "Train")
r2_v,  rmse_v,  mae_v  = evaluate(y_val,   y_pred_val,   "Validation")
r2_te, rmse_te, mae_te = evaluate(y_test,  y_pred_test,  "Test")


# -----------------------------------------------------------------------
# STEP 8 - COMPUTE RESIDUALS
# -----------------------------------------------------------------------
# Residual (error) for each prediction:
#   residual_i = y_actual_i - y_predicted_i
#
# Good residuals should:
#   1. Have mean close to 0 (no systematic bias)
#   2. Show no pattern when plotted vs predicted values
#   3. Be approximately normally distributed

residuals_train = y_train - y_pred_train
residuals_test  = y_test  - y_pred_test

print(f"\n--- Residuals (Test Set) ---")
print(f"  Mean of residuals  : ${np.mean(residuals_test):,.0f}  (should be near 0)")
print(f"  Std of residuals   : ${np.std(residuals_test):,.0f}")


# -----------------------------------------------------------------------
# STEP 9 - VISUALIZATIONS
# -----------------------------------------------------------------------

plt.style.use("seaborn-v0_8-whitegrid")
fig = plt.figure(figsize=(18, 14))
fig.suptitle(
    "Simple Linear Regression  |  House Price vs Area (sqft)",
    fontsize=16, fontweight="bold", y=0.98
)

gs = gridspec.GridSpec(3, 3, figure=fig, hspace=0.45, wspace=0.35)


# --- Plot 1: Raw scatter + regression line ---
ax1 = fig.add_subplot(gs[0, :2])
ax1.scatter(x_train.flatten(), y_train,       color="#4C72B0", alpha=0.35,
            s=18, label="Train data")
ax1.scatter(x_test.flatten(),  y_test,        color="#DD8452", alpha=0.45,
            s=18, label="Test data")

x_line = np.linspace(x.min(), x.max(), 300).reshape(-1, 1)
y_line = model.predict(x_line)
ax1.plot(x_line, y_line, color="#C44E52", linewidth=2.2,
         label=f"Fit: Price = {b0_sklearn:,.0f} + {b1_sklearn:.1f} * Area")

ax1.set_title("Regression Line on Training and Test Data", fontsize=12)
ax1.set_xlabel("Area (sqft)", fontsize=10)
ax1.set_ylabel("House Price (USD)", fontsize=10)
ax1.legend(fontsize=9)
ax1.yaxis.set_major_formatter(plt.FuncFormatter(lambda val, _: f"${val:,.0f}"))


# --- Plot 2: Dataset split pie chart ---
ax2 = fig.add_subplot(gs[0, 2])
split_sizes  = [len(x_train), len(x_val), len(x_test)]
split_labels = [
    f"Train\n{len(x_train)} ({len(x_train)/len(x)*100:.0f}%)",
    f"Validation\n{len(x_val)} ({len(x_val)/len(x)*100:.0f}%)",
    f"Test\n{len(x_test)} ({len(x_test)/len(x)*100:.0f}%)",
]
ax2.pie(split_sizes, labels=split_labels,
        colors=["#4C72B0", "#55A868", "#DD8452"],
        startangle=90, textprops={"fontsize": 9})
ax2.set_title("Dataset Split", fontsize=12)


# --- Plot 3: Actual vs Predicted (test set) ---
ax3 = fig.add_subplot(gs[1, 0])
ax3.scatter(y_test, y_pred_test, color="#4C72B0", alpha=0.5, s=18)
lims = [min(y_test.min(), y_pred_test.min()),
        max(y_test.max(), y_pred_test.max())]
ax3.plot(lims, lims, "r--", linewidth=1.5, label="Perfect prediction (y = x)")
ax3.set_title(f"Actual vs Predicted (Test)\nR2 = {r2_te:.4f}", fontsize=11)
ax3.set_xlabel("Actual Price (USD)", fontsize=9)
ax3.set_ylabel("Predicted Price (USD)", fontsize=9)
ax3.legend(fontsize=8)
ax3.xaxis.set_major_formatter(plt.FuncFormatter(lambda val, _: f"${val/1e3:.0f}k"))
ax3.yaxis.set_major_formatter(plt.FuncFormatter(lambda val, _: f"${val/1e3:.0f}k"))


# --- Plot 4: Residuals vs Predicted ---
ax4 = fig.add_subplot(gs[1, 1])
ax4.scatter(y_pred_test, residuals_test, color="#55A868", alpha=0.5, s=18)
ax4.axhline(y=0, color="red", linestyle="--", linewidth=1.5,
            label="Zero residual line")
ax4.set_title("Residuals vs Predicted Values\n(No pattern = good model)", fontsize=11)
ax4.set_xlabel("Predicted Price (USD)", fontsize=9)
ax4.set_ylabel("Residual (Actual - Predicted)", fontsize=9)
ax4.legend(fontsize=8)
ax4.xaxis.set_major_formatter(plt.FuncFormatter(lambda val, _: f"${val/1e3:.0f}k"))
ax4.yaxis.set_major_formatter(plt.FuncFormatter(lambda val, _: f"${val/1e3:.0f}k"))


# --- Plot 5: Residual distribution histogram ---
ax5 = fig.add_subplot(gs[1, 2])
ax5.hist(residuals_test, bins=30, color="#4C72B0", edgecolor="white", alpha=0.8)
ax5.axvline(x=0, color="red", linestyle="--", linewidth=1.5, label="Zero line")
ax5.axvline(x=np.mean(residuals_test), color="orange", linestyle="-",
            linewidth=1.5, label=f"Mean = ${np.mean(residuals_test):,.0f}")
ax5.set_title("Distribution of Residuals (Test)\n(Should be bell-shaped around 0)", fontsize=11)
ax5.set_xlabel("Residual (USD)", fontsize=9)
ax5.set_ylabel("Frequency", fontsize=9)
ax5.legend(fontsize=8)
ax5.xaxis.set_major_formatter(plt.FuncFormatter(lambda val, _: f"${val/1e3:.0f}k"))


# --- Plot 6: Train vs Val vs Test RMSE comparison bar chart ---
ax6 = fig.add_subplot(gs[2, 0])
bar_labels = ["Train", "Validation", "Test"]
bar_values = [rmse_tr, rmse_v, rmse_te]
bars = ax6.bar(bar_labels, bar_values,
               color=["#4C72B0", "#55A868", "#DD8452"], edgecolor="white")
for bar, val in zip(bars, bar_values):
    ax6.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 500,
             f"${val:,.0f}", ha="center", va="bottom", fontsize=9)
ax6.set_title("RMSE Across Splits\n(Close values = no overfitting)", fontsize=11)
ax6.set_ylabel("RMSE (USD)", fontsize=9)
ax6.yaxis.set_major_formatter(plt.FuncFormatter(lambda val, _: f"${val/1e3:.0f}k"))


# --- Plot 7: R2 across splits ---
ax7 = fig.add_subplot(gs[2, 1])
r2_values = [r2_tr, r2_v, r2_te]
bars2 = ax7.bar(bar_labels, r2_values,
                color=["#4C72B0", "#55A868", "#DD8452"], edgecolor="white")
for bar, val in zip(bars2, r2_values):
    ax7.text(bar.get_x() + bar.get_width() / 2, val + 0.002,
             f"{val:.4f}", ha="center", va="bottom", fontsize=9)
ax7.set_ylim(0, 1.05)
ax7.set_title("R2 Score Across Splits\n(Closer to 1 = better)", fontsize=11)
ax7.set_ylabel("R2 Score", fontsize=9)
ax7.axhline(y=1.0, color="gray", linestyle="--", alpha=0.4)


# --- Plot 8: Feature distribution ---
ax8 = fig.add_subplot(gs[2, 2])
ax8.hist(df["Area_sqft"], bins=30, color="#8172B2", edgecolor="white", alpha=0.8)
ax8.set_title("Distribution of Feature: Area (sqft)", fontsize=11)
ax8.set_xlabel("Area (sqft)", fontsize=9)
ax8.set_ylabel("Count", fontsize=9)
ax8.axvline(x=df["Area_sqft"].mean(), color="red", linestyle="--",
            linewidth=1.5, label=f"Mean = {df['Area_sqft'].mean():.0f}")
ax8.legend(fontsize=8)


plt.savefig("simple_linear_regression_plots.png", dpi=150, bbox_inches="tight")
plt.show()
print("\nPlots saved to: simple_linear_regression_plots.png")

print("\n--- Final Model Summary ---")
print(f"  Equation: Price = {b0_sklearn:,.2f} + {b1_sklearn:.4f} * Area_sqft")
print(f"  Interpretation: For every 1 sqft increase, price rises by ${b1_sklearn:.2f}")
print(f"  Test R2: {r2_te:.4f} (model explains {r2_te*100:.1f}% of price variance)")
print(f"  Test RMSE: ${rmse_te:,.0f} (average prediction error)")
