"""
Multiple Linear Regression on House Price Data
===============================================
We predict House Price (y) using ALL available features:
    Area_sqft, Bedrooms, Bathrooms, Age_years, Distance_km, Garage, Floors

MATHEMATICAL FOUNDATION
-----------------------
The model equation with p features is:
    y = b0 + b1*x1 + b2*x2 + b3*x3 + ... + bp*xp

    where:
        y    = predicted house price
        x1   = Area_sqft
        x2   = Bedrooms
        x3   = Bathrooms
        x4   = Age_years
        x5   = Distance_km
        x6   = Garage (0 or 1)
        x7   = Floors
        b0   = intercept
        b1..b7 = coefficients (slopes for each feature)

In matrix form (much more compact):
    y = X * B

    where:
        X is the design matrix (n x p+1), with a column of 1s prepended for b0
        B is the coefficient vector [b0, b1, ..., bp]

The OLS solution minimizes sum( (y - X*B)^2 ) and is:
    B = (X^T * X)^-1 * X^T * y

    where:
        X^T = transpose of X
        (X^T * X)^-1 = inverse of (X^T * X)

This is called the Normal Equation.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score


# -----------------------------------------------------------------------
# STEP 1 - LOAD DATA
# -----------------------------------------------------------------------
df = pd.read_excel("house_prices.xlsx")

print("Dataset shape:", df.shape)
print("\nColumn names:", list(df.columns))
print("\nFirst 5 rows:")
print(df.head())

print("\nStatistical summary:")
print(df.describe().round(2))


# -----------------------------------------------------------------------
# STEP 2 - SELECT FEATURES AND TARGET
# -----------------------------------------------------------------------
# We use ALL 7 input features to predict Price
feature_columns = [
    "Area_sqft",      # x1 - living area
    "Bedrooms",       # x2 - number of bedrooms
    "Bathrooms",      # x3 - number of bathrooms
    "Age_years",      # x4 - how old the house is (negative effect expected)
    "Distance_km",    # x5 - km from city center (negative effect expected)
    "Garage",         # x6 - binary: has garage (1) or not (0)
    "Floors",         # x7 - number of floors
]

X = df[feature_columns].values   # shape: (800, 7)
y = df["Price_USD"].values        # shape: (800,)

print(f"\nFeature matrix X shape : {X.shape}  (800 samples, 7 features)")
print(f"Target vector y shape  : {y.shape}")


# -----------------------------------------------------------------------
# STEP 3 - SPLIT INTO TRAIN / VALIDATION / TEST
# -----------------------------------------------------------------------
# Same strategy as simple linear regression:
#   70% train, 15% validation, 15% test

X_train, X_temp, y_train, y_temp = train_test_split(
    X, y, test_size=0.30, random_state=42
)

X_val, X_test, y_val, y_test = train_test_split(
    X_temp, y_temp, test_size=0.50, random_state=42
)

print("\n--- Data Split Summary ---")
print(f"  Total   : {len(X)}")
print(f"  Train   : {len(X_train)}  ({len(X_train)/len(X)*100:.1f}%)")
print(f"  Val     : {len(X_val)}    ({len(X_val)/len(X)*100:.1f}%)")
print(f"  Test    : {len(X_test)}   ({len(X_test)/len(X)*100:.1f}%)")


# -----------------------------------------------------------------------
# STEP 4 - FEATURE SCALING (Standardization)
# -----------------------------------------------------------------------
# Why scale?
#   Different features are on very different scales:
#     - Area_sqft ranges from 500 to 4000
#     - Garage is only 0 or 1
#   Without scaling, features with larger magnitudes dominate the cost function.
#
# Standardization (Z-score normalization):
#   x_scaled = (x - mean) / std
#
#   After scaling:
#     - Each feature has mean = 0 and std = 1
#     - Coefficients become comparable (tells us relative feature importance)
#
# IMPORTANT: We fit the scaler ONLY on training data.
#   Then we apply (transform) the same scaler to val and test.
#   This prevents data leakage from val/test into training.

scaler = StandardScaler()

X_train_scaled = scaler.fit_transform(X_train)   # fit + transform on train
X_val_scaled   = scaler.transform(X_val)          # only transform (no fit)
X_test_scaled  = scaler.transform(X_test)         # only transform (no fit)

print("\n--- Feature Scaling Check (Training Data) ---")
for i, col in enumerate(feature_columns):
    print(f"  {col:<15}  mean={X_train_scaled[:, i].mean():.4f}  "
          f"std={X_train_scaled[:, i].std():.4f}")


# -----------------------------------------------------------------------
# STEP 5 - MANUAL NORMAL EQUATION (to see the math explicitly)
# -----------------------------------------------------------------------
# The Normal Equation: B = (X^T * X)^-1 * X^T * y
#
# We add a column of 1s to X_train_scaled so that b0 (intercept)
# is part of the same matrix multiplication.
#
# Design matrix shape: (560, 8)  -- 560 samples, 7 features + 1 bias column

n_train = X_train_scaled.shape[0]
ones_col = np.ones((n_train, 1))                           # bias column
X_design = np.hstack([ones_col, X_train_scaled])           # prepend 1s

# Normal Equation
XT       = X_design.T                                      # transpose
XTX      = XT @ X_design                                   # X^T * X  (8x8 matrix)
XTX_inv  = np.linalg.inv(XTX)                              # (X^T * X)^-1
B_manual = XTX_inv @ XT @ y_train                          # final coefficients

print("\n--- Manual Normal Equation Coefficients ---")
print(f"  Intercept (b0) : {B_manual[0]:,.2f}")
for i, col in enumerate(feature_columns):
    print(f"  {col:<15}  b{i+1} = {B_manual[i+1]:,.2f}")


# -----------------------------------------------------------------------
# STEP 6 - FIT MODEL USING SKLEARN
# -----------------------------------------------------------------------
# sklearn's LinearRegression also uses the Normal Equation internally
# (or SVD for numerical stability)

model = LinearRegression()
model.fit(X_train_scaled, y_train)

print("\n--- Sklearn Coefficients (should match manual) ---")
print(f"  Intercept : {model.intercept_:,.2f}")
for col, coef in zip(feature_columns, model.coef_):
    print(f"  {col:<15}  coef = {coef:,.2f}")


# -----------------------------------------------------------------------
# STEP 7 - MAKE PREDICTIONS
# -----------------------------------------------------------------------
# y_hat = X_scaled @ [b1,...,b7] + b0
#
# The model internally computes this matrix multiplication for us.

y_pred_train = model.predict(X_train_scaled)
y_pred_val   = model.predict(X_val_scaled)
y_pred_test  = model.predict(X_test_scaled)


# -----------------------------------------------------------------------
# STEP 8 - EVALUATE PERFORMANCE METRICS
# -----------------------------------------------------------------------
# Same metrics as simple regression, but now with 7 features.
# We expect better performance than simple linear regression.
#
# Adjusted R2:
#   R2_adj = 1 - (1 - R2) * (n - 1) / (n - p - 1)
#
#   Unlike R2, Adjusted R2 penalizes adding irrelevant features.
#   If a feature doesn't help, R2_adj may decrease.

def adjusted_r2(r2, n, p):
    """
    r2 : regular R2 score
    n  : number of samples
    p  : number of features
    """
    return 1 - (1 - r2) * (n - 1) / (n - p - 1)

def evaluate(y_true, y_pred, split_name, n_features):
    r2      = r2_score(y_true, y_pred)
    adj_r2  = adjusted_r2(r2, len(y_true), n_features)
    mse     = mean_squared_error(y_true, y_pred)
    rmse    = np.sqrt(mse)
    mae     = mean_absolute_error(y_true, y_pred)
    print(f"\n  [{split_name}]")
    print(f"    R2          : {r2:.4f}   (variance explained)")
    print(f"    Adjusted R2 : {adj_r2:.4f}   (penalizes extra features)")
    print(f"    MSE         : ${mse:,.0f}")
    print(f"    RMSE        : ${rmse:,.0f}  (average error in dollars)")
    print(f"    MAE         : ${mae:,.0f}  (average absolute error)")
    return r2, adj_r2, rmse, mae

print("\n--- Model Evaluation ---")
r2_tr, ar2_tr, rmse_tr, mae_tr = evaluate(y_train, y_pred_train, "Train",   7)
r2_v,  ar2_v,  rmse_v,  mae_v  = evaluate(y_val,   y_pred_val,   "Val",     7)
r2_te, ar2_te, rmse_te, mae_te = evaluate(y_test,  y_pred_test,  "Test",    7)


# -----------------------------------------------------------------------
# STEP 9 - FEATURE IMPORTANCE (using standardized coefficients)
# -----------------------------------------------------------------------
# Because all features are now on the same scale (mean=0, std=1),
# the magnitude of each coefficient directly tells us its importance.
#
# Larger absolute value = more influence on price prediction.

importance = pd.DataFrame({
    "Feature":     feature_columns,
    "Coefficient": model.coef_,
    "Abs_Coef":    np.abs(model.coef_),
}).sort_values("Abs_Coef", ascending=False)

print("\n--- Feature Importance (by standardized coefficient magnitude) ---")
print(importance.to_string(index=False))


# -----------------------------------------------------------------------
# STEP 10 - COMPUTE RESIDUALS
# -----------------------------------------------------------------------
residuals_train = y_train - y_pred_train
residuals_test  = y_test  - y_pred_test

print(f"\n--- Residuals (Test Set) ---")
print(f"  Mean    : ${np.mean(residuals_test):,.0f}  (should be near 0)")
print(f"  Std Dev : ${np.std(residuals_test):,.0f}")
print(f"  Min     : ${np.min(residuals_test):,.0f}")
print(f"  Max     : ${np.max(residuals_test):,.0f}")


# -----------------------------------------------------------------------
# STEP 11 - CORRELATION MATRIX (understand feature relationships)
# -----------------------------------------------------------------------
# Pearson correlation: ranges from -1 to +1
#   +1 = perfect positive linear relationship
#   -1 = perfect negative linear relationship
#    0 = no linear relationship
#
# High correlation between features (multicollinearity) can be a problem.

corr_df = df[feature_columns + ["Price_USD"]].corr()


# -----------------------------------------------------------------------
# STEP 12 - VISUALIZATIONS
# -----------------------------------------------------------------------

plt.style.use("seaborn-v0_8-whitegrid")
fig = plt.figure(figsize=(20, 20))
fig.suptitle(
    "Multiple Linear Regression  |  House Price Prediction (7 Features)",
    fontsize=16, fontweight="bold", y=0.99
)

gs = gridspec.GridSpec(4, 3, figure=fig, hspace=0.50, wspace=0.35)


# --- Plot 1: Actual vs Predicted (test set) ---
ax1 = fig.add_subplot(gs[0, 0])
ax1.scatter(y_test, y_pred_test, color="#4C72B0", alpha=0.5, s=18)
lims = [min(y_test.min(), y_pred_test.min()),
        max(y_test.max(), y_pred_test.max())]
ax1.plot(lims, lims, "r--", linewidth=1.5, label="Perfect prediction")
ax1.set_title(f"Actual vs Predicted (Test)\nR2 = {r2_te:.4f}", fontsize=11)
ax1.set_xlabel("Actual Price (USD)", fontsize=9)
ax1.set_ylabel("Predicted Price (USD)", fontsize=9)
ax1.legend(fontsize=8)
ax1.xaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"${v/1e3:.0f}k"))
ax1.yaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"${v/1e3:.0f}k"))


# --- Plot 2: Residuals vs Predicted ---
ax2 = fig.add_subplot(gs[0, 1])
ax2.scatter(y_pred_test, residuals_test, color="#55A868", alpha=0.5, s=18)
ax2.axhline(y=0, color="red", linestyle="--", linewidth=1.5)
ax2.set_title("Residuals vs Predicted\n(Random scatter = no pattern = good)", fontsize=11)
ax2.set_xlabel("Predicted Price (USD)", fontsize=9)
ax2.set_ylabel("Residual (Actual - Predicted)", fontsize=9)
ax2.xaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"${v/1e3:.0f}k"))
ax2.yaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"${v/1e3:.0f}k"))


# --- Plot 3: Residual histogram ---
ax3 = fig.add_subplot(gs[0, 2])
ax3.hist(residuals_test, bins=30, color="#4C72B0", edgecolor="white", alpha=0.8)
ax3.axvline(x=0, color="red", linestyle="--", linewidth=1.5, label="Zero line")
ax3.axvline(x=np.mean(residuals_test), color="orange", linewidth=1.5,
            label=f"Mean = ${np.mean(residuals_test):,.0f}")
ax3.set_title("Residual Distribution (Test)\n(Bell shape around 0 = good)", fontsize=11)
ax3.set_xlabel("Residual (USD)", fontsize=9)
ax3.set_ylabel("Frequency", fontsize=9)
ax3.legend(fontsize=8)
ax3.xaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"${v/1e3:.0f}k"))


# --- Plot 4: Feature importance (standardized coefficients) ---
ax4 = fig.add_subplot(gs[1, :2])
colors = ["#C44E52" if c < 0 else "#4C72B0" for c in importance["Coefficient"]]
bars = ax4.barh(importance["Feature"], importance["Coefficient"],
                color=colors, edgecolor="white")
ax4.axvline(x=0, color="black", linewidth=0.8, linestyle="--")
for bar, val in zip(bars, importance["Coefficient"]):
    x_pos = val + 200 if val >= 0 else val - 200
    ha = "left" if val >= 0 else "right"
    ax4.text(x_pos, bar.get_y() + bar.get_height() / 2,
             f"{val:,.0f}", va="center", ha=ha, fontsize=9)
ax4.set_title(
    "Standardized Coefficients (Feature Importance)\n"
    "Blue = positive effect on price, Red = negative effect",
    fontsize=11
)
ax4.set_xlabel("Coefficient Value (on standardized scale)", fontsize=9)


# --- Plot 5: R2 across splits ---
ax5 = fig.add_subplot(gs[1, 2])
split_labels = ["Train", "Validation", "Test"]
r2_values    = [r2_tr, r2_v, r2_te]
adj_r2_vals  = [ar2_tr, ar2_v, ar2_te]
x_pos = np.arange(3)
width = 0.35
ax5.bar(x_pos - width/2, r2_values, width,
        label="R2", color="#4C72B0", edgecolor="white")
ax5.bar(x_pos + width/2, adj_r2_vals, width,
        label="Adj R2", color="#55A868", edgecolor="white")
ax5.set_xticks(x_pos)
ax5.set_xticklabels(split_labels)
ax5.set_ylim(0, 1.1)
ax5.set_title("R2 and Adjusted R2 Across Splits", fontsize=11)
ax5.set_ylabel("Score", fontsize=9)
ax5.legend(fontsize=9)
for i, (r2, ar2) in enumerate(zip(r2_values, adj_r2_vals)):
    ax5.text(i - width/2, r2 + 0.01, f"{r2:.3f}", ha="center", fontsize=8)
    ax5.text(i + width/2, ar2 + 0.01, f"{ar2:.3f}", ha="center", fontsize=8)


# --- Plot 6: Correlation heatmap ---
ax6 = fig.add_subplot(gs[2, :])
corr_matrix = corr_df.values
cols_all    = feature_columns + ["Price_USD"]
n_cols      = len(cols_all)
im = ax6.imshow(corr_matrix, cmap="RdBu_r", vmin=-1, vmax=1, aspect="auto")
plt.colorbar(im, ax=ax6, shrink=0.8, label="Pearson Correlation")
ax6.set_xticks(range(n_cols))
ax6.set_yticks(range(n_cols))
ax6.set_xticklabels(cols_all, rotation=45, ha="right", fontsize=9)
ax6.set_yticklabels(cols_all, fontsize=9)
for i in range(n_cols):
    for j in range(n_cols):
        val = corr_matrix[i, j]
        text_color = "white" if abs(val) > 0.6 else "black"
        ax6.text(j, i, f"{val:.2f}", ha="center", va="center",
                 fontsize=8, color=text_color)
ax6.set_title(
    "Correlation Matrix (Pearson)\n"
    "Shows linear relationships between all features and target",
    fontsize=12
)


# --- Plot 7: Individual feature scatter plots vs target ---
ax7 = fig.add_subplot(gs[3, 0])
ax8 = fig.add_subplot(gs[3, 1])
ax9 = fig.add_subplot(gs[3, 2])

subplot_features = ["Area_sqft", "Age_years", "Distance_km"]
subplots         = [ax7, ax8, ax9]
colors_scatter   = ["#4C72B0", "#C44E52", "#8172B2"]

for ax, feat, col in zip(subplots, subplot_features, colors_scatter):
    ax.scatter(df[feat], df["Price_USD"],
               color=col, alpha=0.3, s=12, label="All data")
    # Fit a simple trendline for this individual feature
    m = np.polyfit(df[feat], df["Price_USD"], 1)
    x_line = np.linspace(df[feat].min(), df[feat].max(), 200)
    ax.plot(x_line, np.polyval(m, x_line), color="black",
            linewidth=1.8, label="Trend line")
    ax.set_title(f"{feat} vs Price", fontsize=10)
    ax.set_xlabel(feat, fontsize=9)
    ax.set_ylabel("Price (USD)", fontsize=9)
    ax.legend(fontsize=8)
    ax.yaxis.set_major_formatter(
        plt.FuncFormatter(lambda v, _: f"${v/1e3:.0f}k")
    )


plt.savefig("multiple_linear_regression_plots.png", dpi=150, bbox_inches="tight")
plt.show()
print("\nPlots saved to: multiple_linear_regression_plots.png")


# -----------------------------------------------------------------------
# STEP 13 - FINAL SUMMARY
# -----------------------------------------------------------------------
print("\n--- Final Model Summary ---")
print(f"  Equation:")
equation_parts = " + ".join(
    [f"{coef:.2f}*{feat}" for coef, feat in zip(model.coef_, feature_columns)]
)
print(f"    Price = {model.intercept_:,.2f} + {equation_parts}")
print(f"\n  Test Set Performance:")
print(f"    R2   = {r2_te:.4f}  (model explains {r2_te*100:.1f}% of price variance)")
print(f"    RMSE = ${rmse_te:,.0f}  (average prediction error)")
print(f"    MAE  = ${mae_te:,.0f}  (average absolute prediction error)")

print("\n--- Most Important Features (by coefficient magnitude) ---")
for _, row in importance.iterrows():
    direction = "increases" if row["Coefficient"] > 0 else "decreases"
    print(f"  {row['Feature']:<15} : price {direction} by ${abs(row['Coefficient']):,.2f} "
          f"per 1 std unit change")
