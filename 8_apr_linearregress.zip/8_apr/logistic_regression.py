"""
Logistic Regression on House Price Data
========================================
Since Price_USD is continuous, we first convert it into a binary target:

    Is_Expensive = 1  if Price_USD >= median price  (above median, "expensive")
    Is_Expensive = 0  if Price_USD <  median price  (below median, "cheap")

Now the problem becomes:
    Given the house features, predict whether the house is expensive or not.

=============================================================================
MATHEMATICAL FOUNDATION -- READ THIS FIRST
=============================================================================

WHY NOT LINEAR REGRESSION FOR CLASSIFICATION?
----------------------------------------------
If we tried to use linear regression for this:
    y = b0 + b1*x1 + ... + bp*xp

The output can go below 0 or above 1, which makes no sense for a probability.
We need an output that is always between 0 and 1.

THE SIGMOID (LOGISTIC) FUNCTION
---------------------------------
The sigmoid function maps any real number z to the range (0, 1):

    sigma(z) = 1 / (1 + e^(-z))

    where:
        z is called the "log-odds" or "linear combination" of inputs
        z = b0 + b1*x1 + b2*x2 + ... + bp*xp
        e is Euler's number (~2.718)

    When z is very large (e.g., +100) : sigma(z) approaches 1
    When z = 0                        : sigma(z) = 0.5  (decision boundary)
    When z is very negative (e.g., -100): sigma(z) approaches 0

So sigma(z) = P(y=1 | X)  = probability that the house is expensive given X.

THE DECISION RULE
-----------------
    If P(y=1 | X) >= 0.5  =>  predict class 1 (expensive)
    If P(y=1 | X) <  0.5  =>  predict class 0 (cheap)

    The threshold 0.5 corresponds to z = 0, which is the decision boundary.

THE LOSS FUNCTION (Binary Cross-Entropy / Log Loss)
----------------------------------------------------
We cannot use Sum of Squared Errors here because the sigmoid makes the SSE
loss function non-convex (many local minima). Instead, we use Log Loss:

For one sample:
    loss = -[ y * log(p) + (1 - y) * log(1 - p) ]

    where:
        y = actual label (0 or 1)
        p = predicted probability = sigma(z)

    Intuition:
        If y=1 and p is close to 1: log(p) is close to 0 => low loss (good)
        If y=1 and p is close to 0: log(p) is very negative => high loss (bad)
        If y=0 and p is close to 0: log(1-p) is close to 0 => low loss (good)
        If y=0 and p is close to 1: log(1-p) is very negative => high loss (bad)

For all n samples, the total Log Loss is the average:
    L(B) = -(1/n) * sum_i [ y_i * log(p_i) + (1 - y_i) * log(1 - p_i) ]

OPTIMIZATION -- GRADIENT DESCENT
----------------------------------
Unlike linear regression, there is no closed-form solution for logistic regression.
We must use an iterative method called Gradient Descent to minimize L(B).

The gradient (direction of steepest ascent of loss) with respect to B is:
    dL/dB = (1/n) * X^T * (p - y)

    where:
        p = vector of predicted probabilities for all n samples
        y = vector of actual labels
        X = design matrix (n x p+1)

We update the coefficients by stepping in the negative gradient direction:
    B_new = B_old - learning_rate * dL/dB

    where:
        learning_rate (alpha) controls how big each step is
        Too large: overshoots the minimum
        Too small: takes very long to converge

We repeat this until the loss stops decreasing (convergence).

SKLEARN'S APPROACH
-------------------
sklearn uses more advanced solvers (like LBFGS or liblinear) which are
faster than plain gradient descent but minimize the same Log Loss function.
We will implement gradient descent manually to see the math, then use
sklearn to confirm the result.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    accuracy_score, confusion_matrix, classification_report,
    roc_auc_score, roc_curve, log_loss, ConfusionMatrixDisplay
)


# =========================================================================
# STEP 1 - LOAD DATA
# =========================================================================
# Load the same 800-row house dataset used in linear regression.

df = pd.read_excel("house_prices.xlsx")

print("Dataset shape:", df.shape)
print("\nFirst 5 rows:")
print(df.head())


# =========================================================================
# STEP 2 - CREATE BINARY TARGET VARIABLE
# =========================================================================
# We use the median price as the split threshold.
# This guarantees an approximately balanced dataset (50% class 0, 50% class 1).
#
# Choosing the median is better than an arbitrary value because:
#   - It avoids class imbalance (unequal number of 0s and 1s)
#   - Imbalanced classes make accuracy misleading
#     (if 90% are class 0, predicting everything as 0 gives 90% accuracy)

median_price = df["Price_USD"].median()

df["Is_Expensive"] = (df["Price_USD"] >= median_price).astype(int)
# Result: 1 = expensive (price >= median), 0 = cheap (price < median)

print(f"\nMedian price used as threshold: ${median_price:,.2f}")
print(f"\nClass distribution:")
print(df["Is_Expensive"].value_counts())
print(f"  Class 0 (cheap)    : {(df['Is_Expensive']==0).sum()} samples")
print(f"  Class 1 (expensive): {(df['Is_Expensive']==1).sum()} samples")


# =========================================================================
# STEP 3 - SELECT FEATURES AND TARGET
# =========================================================================
# We use all 7 house features as inputs (same as multiple linear regression).
# The target is now the binary label Is_Expensive, NOT Price_USD.

feature_columns = [
    "Area_sqft",    # x1
    "Bedrooms",     # x2
    "Bathrooms",    # x3
    "Age_years",    # x4 (older = cheaper = less likely to be expensive)
    "Distance_km",  # x5 (farther = cheaper = less likely to be expensive)
    "Garage",       # x6
    "Floors",       # x7
]

X = df[feature_columns].values      # shape: (800, 7)
y = df["Is_Expensive"].values       # shape: (800,)  -- 0s and 1s

print(f"\nFeature matrix X shape : {X.shape}")
print(f"Target vector y shape  : {y.shape}")
print(f"Unique target values   : {np.unique(y)}")


# =========================================================================
# STEP 4 - SPLIT INTO TRAIN / VALIDATION / TEST
# =========================================================================
# Same 70 / 15 / 15 split as before.
#
# We use stratify=y to ensure the class ratio (0s to 1s) is preserved
# in each split. Without stratify, one split might get mostly class 1s
# and another mostly class 0s, causing misleading evaluation.

X_train, X_temp, y_train, y_temp = train_test_split(
    X, y, test_size=0.30, random_state=42, stratify=y
)

X_val, X_test, y_val, y_test = train_test_split(
    X_temp, y_temp, test_size=0.50, random_state=42, stratify=y_temp
)

print("\n--- Data Split Summary ---")
print(f"  Total   : {len(X)}  (class 1: {y.sum()}, class 0: {(y==0).sum()})")
print(f"  Train   : {len(X_train)}  (class 1: {y_train.sum()}, class 0: {(y_train==0).sum()})")
print(f"  Val     : {len(X_val)}    (class 1: {y_val.sum()}, class 0: {(y_val==0).sum()})")
print(f"  Test    : {len(X_test)}   (class 1: {y_test.sum()}, class 0: {(y_test==0).sum()})")


# =========================================================================
# STEP 5 - FEATURE SCALING
# =========================================================================
# Gradient descent converges much faster when features are on the same scale.
# Standardization: x_scaled = (x - mean) / std
#
# CRITICAL RULE: Fit scaler only on training data, then transform all sets.
# Fitting on val/test would be data leakage (using future information).

scaler = StandardScaler()

X_train_scaled = scaler.fit_transform(X_train)   # learn mean & std from train only
X_val_scaled   = scaler.transform(X_val)          # apply same scaling (no fitting)
X_test_scaled  = scaler.transform(X_test)         # apply same scaling (no fitting)

print("\n--- Scaling Verification (Train) ---")
for i, col in enumerate(feature_columns):
    print(f"  {col:<15}  mean={X_train_scaled[:,i].mean():.4f}  "
          f"std={X_train_scaled[:,i].std():.4f}")


# =========================================================================
# STEP 6 - MANUAL SIGMOID FUNCTION
# =========================================================================
# sigma(z) = 1 / (1 + e^(-z))
#
# We clip z to avoid numerical overflow in e^(-z) when z is very negative
# (e.g., e^(800) overflows float64). Clipping to [-500, 500] is safe.

def sigmoid(z):
    """
    Compute the sigmoid (logistic) function element-wise.

    Input z is the linear combination: z = X @ B
    Output is a probability between 0 and 1 for each sample.

    sigma(z) = 1 / (1 + e^(-z))
    """
    z = np.clip(z, -500, 500)       # prevent numerical overflow
    return 1.0 / (1.0 + np.exp(-z))


# Quick sanity check
print("\n--- Sigmoid Function Sanity Check ---")
test_inputs = [-10, -1, 0, 1, 10]
for val in test_inputs:
    print(f"  sigmoid({val:>4}) = {sigmoid(val):.6f}")
# Expected: sigmoid(0) = 0.5,  large positive -> near 1, large negative -> near 0


# =========================================================================
# STEP 7 - MANUAL LOG LOSS FUNCTION
# =========================================================================
# L(B) = -(1/n) * sum [ y_i * log(p_i) + (1 - y_i) * log(1 - p_i) ]
#
# We add a small epsilon (1e-15) inside the log to prevent log(0) = -infinity.

def compute_log_loss(y_true, y_pred_prob):
    """
    Compute Binary Cross-Entropy (Log Loss).

    y_true     : actual labels, array of 0s and 1s
    y_pred_prob: predicted probabilities, output of sigmoid, between 0 and 1

    Mathematical interpretation:
        Low loss means predicted probabilities are close to actual labels.
        High loss means predictions are confident but wrong.
    """
    n = len(y_true)
    eps = 1e-15                                     # avoid log(0)
    p = np.clip(y_pred_prob, eps, 1 - eps)          # clip probabilities
    loss = -(1 / n) * np.sum(
        y_true * np.log(p) + (1 - y_true) * np.log(1 - p)
    )
    return loss


# =========================================================================
# STEP 8 - MANUAL GRADIENT DESCENT IMPLEMENTATION
# =========================================================================
# We implement logistic regression FROM SCRATCH using gradient descent.
#
# Algorithm for each iteration (epoch):
#   1. Compute z = X @ B            (linear combination, shape: n)
#   2. Compute p = sigmoid(z)       (predicted probabilities, shape: n)
#   3. Compute error = p - y        (difference between predicted and actual)
#   4. Compute gradient = (1/n) * X^T @ error   (direction of steepest loss increase)
#   5. Update: B = B - learning_rate * gradient  (step against the gradient)
#   6. Compute loss and record it
#   Repeat until convergence.
#
# The design matrix has a column of 1s prepended so b0 (bias/intercept)
# is included in the same matrix multiplication.

def logistic_regression_gradient_descent(
    X, y,
    learning_rate=0.1,
    n_iterations=1000,
    print_every=100
):
    """
    Train logistic regression using gradient descent from scratch.

    Parameters:
        X              : feature matrix (n_samples, n_features)  -- already scaled
        y              : binary target vector (n_samples,)
        learning_rate  : step size for each gradient update (alpha)
        n_iterations   : number of times we loop through the full dataset
        print_every    : how often to print the current loss

    Returns:
        B              : learned coefficient vector (n_features + 1,)
                         B[0] is the intercept, B[1:] are feature weights
        loss_history   : list of loss at each iteration (for plotting)
    """
    n_samples, n_features = X.shape

    # Prepend a column of 1s to X so b0 is handled by the matrix multiplication
    # New shape: (n_samples, n_features + 1)
    ones_col = np.ones((n_samples, 1))
    X_design = np.hstack([ones_col, X])         # design matrix

    # Initialize all coefficients to zero
    # B = [b0, b1, b2, ..., b7]  -- 8 values for 7 features + 1 intercept
    B = np.zeros(n_features + 1)

    loss_history = []

    for iteration in range(n_iterations):

        # --- Forward pass ---
        # z = X_design @ B
        # shape: (n_samples,)
        # This computes b0*1 + b1*x1 + b2*x2 + ... + b7*x7 for every sample
        z = X_design @ B

        # p = sigmoid(z)
        # Converts each z value to a probability between 0 and 1
        # p[i] = P(y[i] = 1 | X[i], B)
        p = sigmoid(z)

        # --- Compute loss ---
        # Binary cross-entropy loss for this iteration
        loss = compute_log_loss(y, p)
        loss_history.append(loss)

        # --- Backward pass (gradient computation) ---
        # error = p - y
        # shape: (n_samples,)
        # This is how wrong our predicted probability is for each sample
        error = p - y

        # gradient = (1/n) * X_design^T @ error
        # shape: (n_features + 1,)
        # Each element is the partial derivative of loss w.r.t. one coefficient
        gradient = (1 / n_samples) * (X_design.T @ error)

        # --- Parameter update (gradient descent step) ---
        # Move B in the direction that reduces loss
        # B_new = B_old - alpha * gradient
        B = B - learning_rate * gradient

        if (iteration + 1) % print_every == 0:
            print(f"  Iteration {iteration+1:>5} / {n_iterations}  |  "
                  f"Log Loss: {loss:.6f}")

    return B, loss_history


print("\n--- Training Logistic Regression via Gradient Descent ---")
B_manual, loss_history = logistic_regression_gradient_descent(
    X_train_scaled, y_train,
    learning_rate=0.1,
    n_iterations=1000,
    print_every=200
)

print("\n--- Manual Gradient Descent Coefficients ---")
print(f"  Intercept (b0) : {B_manual[0]:.6f}")
for col, coef in zip(feature_columns, B_manual[1:]):
    print(f"  {col:<15}  b = {coef:.6f}")


# =========================================================================
# STEP 9 - MANUAL PREDICTIONS FROM GRADIENT DESCENT MODEL
# =========================================================================
# To predict on test set using our manually trained B:
#   1. Prepend 1s column to X_test_scaled
#   2. Compute z = X_design_test @ B
#   3. Compute p = sigmoid(z)
#   4. Predict class 1 if p >= 0.5, else class 0

def predict_manual(X_scaled, B, threshold=0.5):
    """
    Make predictions using manually trained logistic regression coefficients.

    Returns:
        probs  : predicted probabilities (sigmoid output)
        labels : predicted binary labels (0 or 1)
    """
    n = X_scaled.shape[0]
    ones_col = np.ones((n, 1))
    X_design = np.hstack([ones_col, X_scaled])
    z = X_design @ B
    probs = sigmoid(z)
    labels = (probs >= threshold).astype(int)
    return probs, labels

probs_manual_test, labels_manual_test = predict_manual(X_test_scaled, B_manual)

acc_manual = accuracy_score(y_test, labels_manual_test)
print(f"\n--- Manual Gradient Descent Test Accuracy: {acc_manual:.4f} ---")


# =========================================================================
# STEP 10 - FIT MODEL USING SKLEARN (confirms our manual implementation)
# =========================================================================
# sklearn.linear_model.LogisticRegression uses advanced solvers (LBFGS, etc.)
# which minimize the same Log Loss but faster and more accurately.
#
# C = 1/lambda is the regularization parameter:
#   - Regularization adds a penalty for large coefficients to prevent overfitting
#   - C=1e6 means very weak regularization (close to pure logistic regression)
#     so results match our manual gradient descent closely.

model = LogisticRegression(
    C=1e6,               # very weak regularization for fair comparison
    max_iter=1000,       # maximum number of solver iterations
    random_state=42,
    solver="lbfgs"       # Limited-memory BFGS -- a fast second-order optimizer
)
model.fit(X_train_scaled, y_train)

print("\n--- Sklearn Coefficients ---")
print(f"  Intercept (b0) : {model.intercept_[0]:.6f}")
for col, coef in zip(feature_columns, model.coef_[0]):
    print(f"  {col:<15}  b = {coef:.6f}")


# =========================================================================
# STEP 11 - PREDICTIONS FROM SKLEARN MODEL
# =========================================================================
# predict_proba returns [P(y=0), P(y=1)] for each sample
# We use [:, 1] to get P(y=1) = probability of being expensive

y_prob_train = model.predict_proba(X_train_scaled)[:, 1]
y_prob_val   = model.predict_proba(X_val_scaled)[:, 1]
y_prob_test  = model.predict_proba(X_test_scaled)[:, 1]

y_pred_train = model.predict(X_train_scaled)
y_pred_val   = model.predict(X_val_scaled)
y_pred_test  = model.predict(X_test_scaled)


# =========================================================================
# STEP 12 - EVALUATION METRICS FOR CLASSIFICATION
# =========================================================================
#
# ACCURACY:
#   Accuracy = (correct predictions) / (total predictions)
#   Good when classes are balanced. Misleading when imbalanced.
#
# CONFUSION MATRIX:
#   A 2x2 table:
#
#               Predicted 0    Predicted 1
#   Actual 0   [  TN           FP  ]   TN = True Negative  (correctly said "cheap")
#   Actual 1   [  FN           TP  ]   TP = True Positive  (correctly said "expensive")
#                                       FP = False Positive (said "expensive", was cheap)
#                                       FN = False Negative (said "cheap", was expensive)
#
# PRECISION:
#   Precision = TP / (TP + FP)
#   Of all houses we predicted as expensive, what fraction actually were?
#
# RECALL (Sensitivity):
#   Recall = TP / (TP + FN)
#   Of all houses that were actually expensive, what fraction did we catch?
#
# F1 SCORE:
#   F1 = 2 * (Precision * Recall) / (Precision + Recall)
#   Harmonic mean of Precision and Recall.
#   Useful when you want to balance both Precision and Recall.
#
# ROC-AUC:
#   AUC = Area Under the ROC Curve
#   ROC plots True Positive Rate vs False Positive Rate at every threshold.
#   AUC = 1.0 is perfect, AUC = 0.5 is random guessing.
#   AUC measures how well the model ranks positive samples above negative ones.
#
# LOG LOSS:
#   Lower is better.
#   Measures how confident and correct the predicted probabilities are.
#   A model that predicts 0.51 for the correct class has lower log loss
#   than one that predicts 0.99 for the wrong class.

def evaluate_classification(y_true, y_pred, y_prob, split_name):
    acc  = accuracy_score(y_true, y_pred)
    auc  = roc_auc_score(y_true, y_prob)
    ll   = log_loss(y_true, y_prob)
    cm   = confusion_matrix(y_true, y_pred)
    tn, fp, fn, tp = cm.ravel()
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0
    recall    = tp / (tp + fn) if (tp + fn) > 0 else 0
    f1        = (2 * precision * recall / (precision + recall)
                 if (precision + recall) > 0 else 0)
    print(f"\n  [{split_name}]")
    print(f"    Accuracy  : {acc:.4f}   ({acc*100:.1f}% of predictions correct)")
    print(f"    Precision : {precision:.4f}   (of predicted expensive, {precision*100:.1f}% truly were)")
    print(f"    Recall    : {recall:.4f}   (of actual expensive, caught {recall*100:.1f}%)")
    print(f"    F1 Score  : {f1:.4f}   (harmonic mean of precision and recall)")
    print(f"    ROC-AUC   : {auc:.4f}   (1.0 = perfect, 0.5 = random)")
    print(f"    Log Loss  : {ll:.4f}   (lower is better)")
    print(f"    Confusion Matrix: TN={tn}, FP={fp}, FN={fn}, TP={tp}")
    return acc, auc, ll, f1

print("\n--- Classification Evaluation ---")
acc_tr, auc_tr, ll_tr, f1_tr = evaluate_classification(
    y_train, y_pred_train, y_prob_train, "Train"
)
acc_v, auc_v, ll_v, f1_v = evaluate_classification(
    y_val, y_pred_val, y_prob_val, "Validation"
)
acc_te, auc_te, ll_te, f1_te = evaluate_classification(
    y_test, y_pred_test, y_prob_test, "Test"
)

print("\n--- Full Classification Report (Test Set) ---")
print(classification_report(
    y_test, y_pred_test,
    target_names=["Cheap (0)", "Expensive (1)"]
))


# =========================================================================
# STEP 13 - VISUALIZATIONS
# =========================================================================

plt.style.use("seaborn-v0_8-whitegrid")
fig = plt.figure(figsize=(20, 22))
fig.suptitle(
    "Logistic Regression  |  House Price Classification (Expensive vs Cheap)",
    fontsize=16, fontweight="bold", y=0.99
)

gs = gridspec.GridSpec(4, 3, figure=fig, hspace=0.50, wspace=0.38)


# -----------------------------------------------------------------
# Plot 1: Sigmoid Function Shape
# -----------------------------------------------------------------
# Shows the sigmoid curve and how it maps any z to a probability.
# The decision boundary is at z=0 where probability = 0.5.
ax1 = fig.add_subplot(gs[0, 0])
z_range = np.linspace(-8, 8, 300)
sig_vals = sigmoid(z_range)
ax1.plot(z_range, sig_vals, color="#4C72B0", linewidth=2.5,
         label="sigma(z) = 1 / (1 + e^(-z))")
ax1.axhline(y=0.5, color="red", linestyle="--", linewidth=1.2,
            label="Decision boundary (p=0.5)")
ax1.axvline(x=0, color="gray", linestyle="--", linewidth=1.0)
ax1.fill_between(z_range, sig_vals, 0.5,
                 where=(sig_vals > 0.5), alpha=0.12, color="green",
                 label="Predict class 1 (expensive)")
ax1.fill_between(z_range, sig_vals, 0.5,
                 where=(sig_vals < 0.5), alpha=0.12, color="red",
                 label="Predict class 0 (cheap)")
ax1.set_title("The Sigmoid Function\nMaps any real number z to (0, 1)", fontsize=11)
ax1.set_xlabel("z  (linear combination of features)", fontsize=9)
ax1.set_ylabel("P(y=1 | X)  =  sigma(z)", fontsize=9)
ax1.legend(fontsize=7.5)
ax1.set_ylim(-0.05, 1.05)


# -----------------------------------------------------------------
# Plot 2: Gradient Descent -- Loss curve over iterations
# -----------------------------------------------------------------
# This shows the training loss decreasing as gradient descent runs.
# A smooth downward curve means the learning rate is well chosen.
ax2 = fig.add_subplot(gs[0, 1])
ax2.plot(range(1, len(loss_history) + 1), loss_history,
         color="#C44E52", linewidth=2)
ax2.set_title("Gradient Descent Convergence\nLog Loss decreasing over iterations", fontsize=11)
ax2.set_xlabel("Iteration", fontsize=9)
ax2.set_ylabel("Binary Cross-Entropy Loss", fontsize=9)
ax2.annotate(
    f"Final loss: {loss_history[-1]:.4f}",
    xy=(len(loss_history), loss_history[-1]),
    xytext=(len(loss_history)*0.6, loss_history[0]*0.6),
    arrowprops=dict(arrowstyle="->", color="black"),
    fontsize=9
)


# -----------------------------------------------------------------
# Plot 3: Dataset split pie with class balance per split
# -----------------------------------------------------------------
ax3 = fig.add_subplot(gs[0, 2])
split_sizes  = [len(X_train), len(X_val), len(X_test)]
split_labels = [
    f"Train\n{len(X_train)} ({len(X_train)/len(X)*100:.0f}%)",
    f"Validation\n{len(X_val)} ({len(X_val)/len(X)*100:.0f}%)",
    f"Test\n{len(X_test)} ({len(X_test)/len(X)*100:.0f}%)",
]
ax3.pie(split_sizes, labels=split_labels,
        colors=["#4C72B0", "#55A868", "#DD8452"],
        startangle=90, textprops={"fontsize": 9})
ax3.set_title("Dataset Split (stratified)", fontsize=11)


# -----------------------------------------------------------------
# Plot 4: Confusion Matrix (Test Set)
# -----------------------------------------------------------------
# Visual breakdown of correct and incorrect predictions.
ax4 = fig.add_subplot(gs[1, 0])
cm_test = confusion_matrix(y_test, y_pred_test)
disp = ConfusionMatrixDisplay(
    confusion_matrix=cm_test,
    display_labels=["Cheap (0)", "Expensive (1)"]
)
disp.plot(ax=ax4, colorbar=False, cmap="Blues")
ax4.set_title(
    f"Confusion Matrix (Test Set)\nAccuracy = {acc_te:.4f}",
    fontsize=11
)
ax4.set_xlabel("Predicted Label", fontsize=9)
ax4.set_ylabel("Actual Label", fontsize=9)


# -----------------------------------------------------------------
# Plot 5: ROC Curve
# -----------------------------------------------------------------
# The ROC curve plots True Positive Rate (Recall) vs False Positive Rate
# as the classification threshold varies from 0 to 1.
#
# TPR = TP / (TP + FN)  -- what fraction of actual positives we catch
# FPR = FP / (FP + TN)  -- what fraction of actual negatives we misclassify
#
# The diagonal line (AUC=0.5) represents random guessing.
# Our curve above the diagonal means better than random.
ax5 = fig.add_subplot(gs[1, 1])
fpr_train, tpr_train, _ = roc_curve(y_train, y_prob_train)
fpr_test,  tpr_test,  _ = roc_curve(y_test,  y_prob_test)
ax5.plot(fpr_train, tpr_train, color="#4C72B0", linewidth=2,
         label=f"Train  (AUC = {auc_tr:.4f})")
ax5.plot(fpr_test,  tpr_test,  color="#DD8452", linewidth=2,
         label=f"Test   (AUC = {auc_te:.4f})")
ax5.plot([0, 1], [0, 1], "k--", linewidth=1, label="Random (AUC = 0.50)")
ax5.fill_between(fpr_test, tpr_test, alpha=0.12, color="#DD8452")
ax5.set_title("ROC Curve\n(Higher and to the left = better model)", fontsize=11)
ax5.set_xlabel("False Positive Rate  (1 - Specificity)", fontsize=9)
ax5.set_ylabel("True Positive Rate  (Sensitivity / Recall)", fontsize=9)
ax5.legend(fontsize=9)


# -----------------------------------------------------------------
# Plot 6: Predicted Probability Distribution
# -----------------------------------------------------------------
# Shows how confident the model is.
# A good model pushes probabilities towards 0 and 1 (bimodal).
# A weak model has probabilities clustered around 0.5 (uncertain).
ax6 = fig.add_subplot(gs[1, 2])
ax6.hist(y_prob_test[y_test == 0], bins=25, alpha=0.65,
         color="#4C72B0", label="Actual: Cheap (0)", edgecolor="white")
ax6.hist(y_prob_test[y_test == 1], bins=25, alpha=0.65,
         color="#DD8452", label="Actual: Expensive (1)", edgecolor="white")
ax6.axvline(x=0.5, color="red", linestyle="--", linewidth=1.5,
            label="Decision threshold (0.5)")
ax6.set_title("Predicted Probability Distribution (Test)\n"
              "Good: two peaks near 0 and 1", fontsize=11)
ax6.set_xlabel("P(Is_Expensive = 1)", fontsize=9)
ax6.set_ylabel("Count", fontsize=9)
ax6.legend(fontsize=9)


# -----------------------------------------------------------------
# Plot 7: Feature Coefficients (Standardized)
# -----------------------------------------------------------------
# Coefficients here are log-odds coefficients.
# A coefficient b_j means:
#   For a 1-unit increase in x_j (in standardized scale),
#   the log-odds of being expensive change by b_j.
#
#   Equivalently, the odds ratio = e^(b_j)
#   e.g., if b_j = 0.5, the odds of being expensive multiply by e^0.5 = 1.65
ax7 = fig.add_subplot(gs[2, :2])
coefs   = model.coef_[0]
colors  = ["#C44E52" if c < 0 else "#4C72B0" for c in coefs]
sorted_idx = np.argsort(coefs)
sorted_coefs = coefs[sorted_idx]
sorted_names = [feature_columns[i] for i in sorted_idx]
sorted_colors = [colors[i] for i in sorted_idx]
bars = ax7.barh(sorted_names, sorted_coefs,
                color=sorted_colors, edgecolor="white")
ax7.axvline(x=0, color="black", linewidth=0.8, linestyle="--")
for bar, val in zip(bars, sorted_coefs):
    x_pos = val + 0.02 if val >= 0 else val - 0.02
    ha = "left" if val >= 0 else "right"
    ax7.text(x_pos, bar.get_y() + bar.get_height() / 2,
             f"{val:.4f}  (odds ratio: {np.exp(val):.3f})",
             va="center", ha=ha, fontsize=8.5)
ax7.set_title(
    "Logistic Regression Coefficients (Log-Odds Scale)\n"
    "Positive = increases probability of being expensive  |  "
    "Odds ratio = e^coefficient",
    fontsize=11
)
ax7.set_xlabel("Log-Odds Coefficient", fontsize=9)


# -----------------------------------------------------------------
# Plot 8: Accuracy, F1, AUC comparison across splits
# -----------------------------------------------------------------
ax8 = fig.add_subplot(gs[2, 2])
split_names = ["Train", "Val", "Test"]
metrics     = {
    "Accuracy": [acc_tr, acc_v, acc_te],
    "F1 Score": [f1_tr, f1_v, f1_te],
    "ROC-AUC":  [auc_tr, auc_v, auc_te],
}
x_pos   = np.arange(3)
width   = 0.25
offsets = [-width, 0, width]
met_colors = ["#4C72B0", "#55A868", "#DD8452"]
for (metric_name, values), offset, col in zip(metrics.items(), offsets, met_colors):
    ax8.bar(x_pos + offset, values, width, label=metric_name,
            color=col, edgecolor="white")
ax8.set_xticks(x_pos)
ax8.set_xticklabels(split_names)
ax8.set_ylim(0, 1.15)
ax8.set_title("Metrics Across Splits\n(Close values = no overfitting)", fontsize=11)
ax8.set_ylabel("Score", fontsize=9)
ax8.legend(fontsize=8)
ax8.axhline(y=1.0, color="gray", linestyle="--", alpha=0.4)


# -----------------------------------------------------------------
# Plot 9: Manual GD vs Sklearn -- coefficient comparison
# -----------------------------------------------------------------
# Visual proof that gradient descent converges to the same solution as sklearn.
ax9 = fig.add_subplot(gs[3, :])
manual_coefs  = B_manual[1:]          # skip intercept for feature comparison
sklearn_coefs = model.coef_[0]
x_feat = np.arange(len(feature_columns))
width2 = 0.35
ax9.bar(x_feat - width2/2, manual_coefs, width2,
        label="Manual Gradient Descent", color="#4C72B0", edgecolor="white", alpha=0.85)
ax9.bar(x_feat + width2/2, sklearn_coefs, width2,
        label="Sklearn (LBFGS solver)", color="#DD8452", edgecolor="white", alpha=0.85)
ax9.set_xticks(x_feat)
ax9.set_xticklabels(feature_columns, rotation=15, ha="right", fontsize=9)
ax9.set_title(
    "Coefficient Comparison: Manual Gradient Descent vs Sklearn\n"
    "Bars should be nearly equal -- confirms our implementation is correct",
    fontsize=11
)
ax9.set_ylabel("Coefficient (Log-Odds)", fontsize=9)
ax9.axhline(y=0, color="black", linewidth=0.6, linestyle="--")
ax9.legend(fontsize=9)


plt.savefig("logistic_regression_plots.png", dpi=150, bbox_inches="tight")
plt.show()
print("\nPlots saved to: logistic_regression_plots.png")


# =========================================================================
# STEP 14 - FINAL SUMMARY
# =========================================================================
print("\n" + "="*65)
print("FINAL MODEL SUMMARY")
print("="*65)
print(f"\n  Target         : Is_Expensive  (1 = Price >= ${median_price:,.0f}, 0 = below)")
print(f"  Features used  : {len(feature_columns)}")
print(f"\n  Test Set Performance:")
print(f"    Accuracy  = {acc_te:.4f}  ({acc_te*100:.1f}% of test houses classified correctly)")
print(f"    F1 Score  = {f1_te:.4f}  (balanced precision-recall)")
print(f"    ROC-AUC   = {auc_te:.4f}  (ranking quality)")
print(f"    Log Loss  = {ll_te:.4f}  (probability calibration quality)")
print(f"\n  Manual GD Test Accuracy  : {acc_manual:.4f}")
print(f"  Sklearn Test Accuracy    : {acc_te:.4f}")
print(f"  (difference = {abs(acc_manual - acc_te):.4f}, confirms implementation is correct)")

print("\n  Feature influence on probability of being Expensive:")
for col, coef in sorted(
    zip(feature_columns, model.coef_[0]), key=lambda t: abs(t[1]), reverse=True
):
    direction = "increases" if coef > 0 else "decreases"
    print(f"    {col:<15}  {direction} odds by factor {np.exp(coef):.3f}  "
          f"(coef = {coef:+.4f})")
